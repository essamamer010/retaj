<?php
// Receives the quote / inquiry forms and emails them to the company.
// Works on any shared hosting (cPanel) that allows PHP mail().
header('Content-Type: application/json; charset=utf-8');

$TO = 'info@retaj-egy.com';          // where the requests arrive
$FROM_DOMAIN = $_SERVER['HTTP_HOST'] ?? 'retaj-egy.com';
$FROM_DOMAIN = preg_replace('/^www\./', '', $FROM_DOMAIN);
$FROM = 'noreply@' . $FROM_DOMAIN;   // must be an address on your own domain

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['ok' => false]);
    exit;
}

// Honeypot: real users never fill this field
if (!empty($data['website'])) {
    echo json_encode(['ok' => true]);
    exit;
}

function clean($v) {
    $v = is_string($v) ? $v : '';
    $v = strip_tags($v);
    return trim(str_replace(["\r", "\n"], ' ', $v));
}

$name = clean($data['name'] ?? '');
$phone = clean($data['phone'] ?? '');
if ($name === '' || $phone === '') {
    http_response_code(422);
    echo json_encode(['ok' => false]);
    exit;
}

$labels = [
    'name' => 'الاسم',
    'phone' => 'الموبايل',
    'company' => 'الشركة',
    'model' => 'الموديل',
    'request_type' => 'نوع الطلب',
    'quantity' => 'الكمية',
    'category' => 'القسم',
    'notes' => 'ملاحظات',
];

$body = "طلب جديد من موقع الريتاج\n\n";
foreach ($labels as $key => $label) {
    $val = clean($data[$key] ?? '');
    if ($val !== '') {
        $body .= $label . ': ' . $val . "\n";
    }
}

$subject = '=?UTF-8?B?' . base64_encode('طلب جديد من الموقع — ' . $name) . '?=';
$headers = "From: $FROM\r\n" .
           "Reply-To: $FROM\r\n" .
           "Content-Type: text/plain; charset=UTF-8\r\n";

$sent = @mail($TO, $subject, $body, $headers);
echo json_encode(['ok' => (bool)$sent]);
