// Downloads every image used by the site from Base44 into public/images
// and rewrites the data files to point to the local copies.
// Run once:  npm run images
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const outDir = path.join(root, "public", "images");
await fs.mkdir(outDir, { recursive: true });

const cache = new Map();
let counter = 0;

async function localize(url) {
  if (!url || !/^https?:\/\//.test(url)) return url;
  if (cache.has(url)) return cache.get(url);
  const base = decodeURIComponent(new URL(url).pathname.split("/").pop() || "image.jpg");
  const safe = base.replace(/[^a-zA-Z0-9._-]/g, "_");
  const name = `${String(++counter).padStart(2, "0")}-${safe}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed (${res.status}): ${url}`);
  await fs.writeFile(path.join(outDir, name), Buffer.from(await res.arrayBuffer()));
  const local = `/images/${name}`;
  cache.set(url, local);
  console.log("OK ", local);
  return local;
}

const dataDir = path.join(root, "src", "data");

// machines
const mPath = path.join(dataDir, "machines.json");
const machines = JSON.parse(await fs.readFile(mPath, "utf8"));
for (const m of machines) m.image = await localize(m.image);
await fs.writeFile(mPath, JSON.stringify(machines, null, 2));

// home + maintenance images
const iPath = path.join(dataDir, "images.json");
const images = JSON.parse(await fs.readFile(iPath, "utf8"));
for (const k of Object.keys(images)) images[k] = await localize(images[k]);
await fs.writeFile(iPath, JSON.stringify(images, null, 2));

console.log("\nDone. Now run: npm run build");
