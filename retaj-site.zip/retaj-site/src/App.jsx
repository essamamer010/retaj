import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import ScrollToTop from "@/components/ScrollToTop";
import { ThemeProvider } from "@/lib/theme";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Machines from "@/pages/Machines";
import Toners from "@/pages/Toners";
import Maintenance from "@/pages/Maintenance";
import MfpSystemsPage from "@/pages/MfpSystemsPage";

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="text-center">
        <h1 className="text-7xl font-light text-muted-foreground">404</h1>
        <p className="mt-4 text-lg">الصفحة غير موجودة</p>
        <Link
          to="/"
          className="mt-6 inline-flex px-5 py-3 rounded-2xl bg-accent text-accent-foreground font-bold"
        >
          الرئيسية
        </Link>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <ThemeProvider>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/machines" element={<Machines />} />
            <Route path="/toners" element={<Toners />} />
            <Route path="/maintenance" element={<Maintenance />} />
            <Route path="/mfp-systems" element={<MfpSystemsPage />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </ThemeProvider>
    </Router>
  );
}
