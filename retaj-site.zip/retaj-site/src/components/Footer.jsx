import React from "react";
import { Link } from "react-router-dom";
import { Phone, MessageCircle, Mail, MapPin, Printer } from "lucide-react";
import { SITE, waLink, NAV_LINKS } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="relative mt-24 border-t border-border/60 bg-surface">
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10 py-14">
        <div className="grid gap-10 md:grid-cols-4">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <span className="grid place-items-center w-10 h-10 rounded-xl ink-gradient text-white">
                <Printer className="w-5 h-5" />
              </span>
              <span className="leading-tight">
                <span className="block font-heading font-extrabold text-lg">{SITE.brand}</span>
                <span className="block text-[11px] text-muted-foreground">{SITE.tagline}</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-md">
              جميع موديلات ماكينات التصوير توشيبا، أحبار أصلية وهاي كوبي وتعبئة، وصيانة احترافية
              بضمان سنة شامل — في خدمة عملائنا في جميع أنحاء جمهورية مصر العربية.
            </p>
            <div className="flex flex-wrap gap-2 mt-5">
              <a
                href={`tel:${SITE.phoneTel}`}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent text-accent-foreground text-sm font-bold"
              >
                <Phone className="w-4 h-4" /> اتصل الآن
              </a>
              <a
                href={waLink()}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#25D366] text-white text-sm font-bold"
              >
                <MessageCircle className="w-4 h-4" /> واتساب
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-heading font-bold mb-4">روابط سريعة</h4>
            <ul className="space-y-2.5 text-sm">
              {NAV_LINKS.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="text-muted-foreground hover:text-accent transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading font-bold mb-4">تواصل معنا</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 text-accent shrink-0" />
                <a href={SITE.mapsUrl} target="_blank" rel="noreferrer" className="hover:text-foreground">
                  {SITE.address}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-accent" />
                <a href={`tel:${SITE.phoneTel}`} className="hover:text-foreground" dir="ltr">
                  {SITE.phone}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-accent" />
                <a href={`mailto:${SITE.email}`} className="hover:text-foreground" dir="ltr">
                  {SITE.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-border/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} {SITE.brand} — جميع الحقوق محفوظة.</p>
          <p>ماكينات تصوير توشيبا · أحبار · صيانة احترافية</p>
        </div>
      </div>
    </footer>
  );
}
