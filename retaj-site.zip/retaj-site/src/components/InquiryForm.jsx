import React, { useState } from "react";
import { sendInquiry } from "@/lib/inquiry";
import { Send, Loader2, CheckCircle2 } from "lucide-react";

export default function InquiryForm({ category, requestLabel, requestOptions }) {
  const empty = {
    name: "",
    phone: "",
    company: "",
    model: "",
    request_type: "",
    quantity: "",
    notes: "",
    website: "",
  };
  const [form, setForm] = useState(empty);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      setError("من فضلك أكمل الاسم ورقم الموبايل.");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      await sendInquiry({ ...form, category });
      setDone(true);
      setForm(empty);
    } catch {
      setError("حدث خطأ أثناء الإرسال. حاول مرة أخرى أو تواصل معنا على الواتساب.");
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="bg-card rounded-3xl border border-border/60 p-8 text-center">
        <CheckCircle2 className="w-14 h-14 text-accent mx-auto mb-4" />
        <h3 className="font-heading text-xl font-extrabold">تم استلام طلبك</h3>
        <p className="mt-2 text-muted-foreground">سيتم التواصل معك في أقرب وقت لتأكيد الطلب.</p>
        <button
          onClick={() => setDone(false)}
          className="mt-6 px-5 py-2.5 rounded-2xl bg-secondary font-bold text-sm hover:bg-primary/30 transition"
        >
          إرسال طلب آخر
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="bg-card rounded-3xl border border-border/60 p-6 lg:p-8">
      {/* honeypot (hidden from real users) */}
      <input
        type="text"
        name="website"
        value={form.website}
        onChange={(e) => set("website", e.target.value)}
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        style={{ position: "absolute", left: "-9999px", opacity: 0, height: 0, width: 0 }}
      />
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="الاسم *">
          <input
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
            className="input"
            placeholder="اسمك الكامل"
          />
        </Field>
        <Field label="رقم الموبايل *">
          <input
            value={form.phone}
            onChange={(e) => set("phone", e.target.value)}
            className="input"
            placeholder="01xxxxxxxxx"
            dir="ltr"
          />
        </Field>
        <Field label="اسم الشركة">
          <input
            value={form.company}
            onChange={(e) => set("company", e.target.value)}
            className="input"
            placeholder="اسم الشركة (اختياري)"
          />
        </Field>
        <Field label={category === "toner" ? "موديل الحبارة المطلوبة *" : "موديل الماكينة *"}>
          <input
            value={form.model}
            onChange={(e) => set("model", e.target.value)}
            className="input"
            placeholder={category === "toner" ? "مثال: 2508/3008/3508" : "مثال: e-STUDIO 2508A"}
          />
        </Field>
        <Field label={requestLabel}>
          <select
            value={form.request_type}
            onChange={(e) => set("request_type", e.target.value)}
            className="input"
          >
            <option value="">— اختار —</option>
            {requestOptions.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        </Field>
        {category === "toner" && (
          <Field label="الكمية">
            <input
              value={form.quantity}
              onChange={(e) => set("quantity", e.target.value)}
              className="input"
              placeholder="الكمية المطلوبة"
            />
          </Field>
        )}
      </div>

      <div className="mt-4">
        <Field label="ملاحظات">
          <textarea
            value={form.notes}
            onChange={(e) => set("notes", e.target.value)}
            className="input min-h-[96px] resize-y"
            placeholder="أي تفاصيل إضافية"
          />
        </Field>
      </div>

      {error && <p className="mt-4 text-sm text-destructive font-semibold">{error}</p>}

      <button
        type="submit"
        disabled={submitting}
        className="mt-6 inline-flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl bg-accent text-accent-foreground font-bold hover:brightness-105 transition disabled:opacity-60"
      >
        {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-4 h-4" />}
        إرسال الطلب
      </button>
      <p className="mt-3 text-center text-xs text-muted-foreground">
        سيتم التواصل معك في أقرب وقت لتأكيد الطلب.
      </p>

      <style>{`
        .input {
          width: 100%;
          padding: 0.7rem 1rem;
          border-radius: 0.85rem;
          border: 1px solid hsl(var(--border));
          background: hsl(var(--background));
          color: hsl(var(--foreground));
          font-size: 0.95rem;
          outline: none;
          transition: border-color .2s, box-shadow .2s;
        }
        .input:focus { border-color: hsl(var(--accent)); box-shadow: 0 0 0 3px hsl(var(--accent) / .15); }
      `}</style>
    </form>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block text-sm font-semibold mb-1.5">{label}</span>
      {children}
    </label>
  );
}
