import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import SearchOverlay from "@/components/SearchOverlay";
import { QuoteProvider } from "@/components/QuoteModal";
import { allMachines, allToners } from "@/lib/data";

export default function Layout() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <QuoteProvider>
      <div className="min-h-screen flex flex-col">
        <Navbar onOpenSearch={() => setSearchOpen(true)} />
        <main className="flex-1">
          <Outlet context={{ openSearch: () => setSearchOpen(true) }} />
        </main>
        <Footer />
        <WhatsAppButton />
        <SearchOverlay
          open={searchOpen}
          onClose={() => setSearchOpen(false)}
          machines={allMachines}
          toners={allToners}
        />
      </div>
    </QuoteProvider>
  );
}
