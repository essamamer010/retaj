import React from "react";
import { Gauge, Layers, MessageCircle } from "lucide-react";
import { Image } from "@/components/ui/image";
import { useQuote } from "@/components/QuoteModal";

const TYPE_LABELS = { color: "ألوان", bw: "أبيض وأسود" };

export default function MachineCard({ machine }) {
  const m = machine;
  const { requestQuote } = useQuote();
  return (
    <article className="lift group flex flex-col bg-card rounded-3xl border border-border/70 overflow-hidden shadow-sm">
      {/* Image */}
      <div className="relative aspect-square bg-gradient-to-br from-secondary to-primary/20 overflow-hidden">
        <Image
          src={m.image}
          alt={m.name}
          fittingType="fit"
          className="w-full h-full object-contain p-6 transition-transform duration-500 group-hover:scale-105"
        />
        <span className="absolute top-4 start-4 px-3 py-1 rounded-full text-xs font-bold bg-card/90 backdrop-blur border border-border/60 shadow-sm">
          {TYPE_LABELS[m.type] || m.type}
        </span>
        <div className="absolute top-4 end-4 flex flex-col items-end gap-1">
          <span className="grid place-items-center w-14 h-14 rounded-2xl ink-gradient text-white shadow-md">
            <Gauge className="w-5 h-5 mb-0.5" />
            <span className="text-lg font-extrabold leading-none">{m.speed}</span>
          </span>
          <span className="text-[10px] font-semibold text-muted-foreground">ورقة/د</span>
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-col flex-1 p-5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-heading text-xl font-extrabold">{m.name}</h3>
            <p className="text-xs text-muted-foreground mt-0.5" dir="ltr">{m.model}</p>
          </div>
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground bg-secondary px-2.5 py-1 rounded-full">
            <Layers className="w-3.5 h-3.5" /> {m.paper_size}
          </span>
        </div>

        <p className="mt-3 text-sm text-muted-foreground leading-relaxed line-clamp-2">{m.description}</p>

        <p className="mt-3 text-xs font-semibold text-foreground/70">
          <span className="text-accent font-bold">{m.capacity}</span> نسخة شهريًا (موصى به)
        </p>

        <ul className="mt-3 flex flex-wrap gap-1.5">
          {m.features?.slice(0, 4).map((f) => (
            <li key={f} className="text-[11px] px-2 py-1 rounded-full bg-secondary text-foreground/70">
              {f}
            </li>
          ))}
        </ul>

        <button
          onClick={() => requestQuote({ name: m.name, model: m.model, category: "machine" })}
          className="mt-5 inline-flex items-center justify-center gap-2 w-full py-3 rounded-2xl bg-accent text-accent-foreground font-bold text-sm hover:brightness-105 transition"
        >
          <MessageCircle className="w-4 h-4" /> اطلب عرض سعر
        </button>
      </div>
    </article>
  );
}
