import React from "react";
import { MessageCircle, Cpu, Check } from "lucide-react";
import { Image } from "@/components/ui/image";
import { useQuote } from "@/components/QuoteModal";

export default function MfpCard({ system }) {
  const s = system;
  const { requestQuote } = useQuote();
  return (
    <article className="lift group relative flex flex-col bg-card rounded-3xl border border-border/70 overflow-hidden shadow-sm">
      {/* MFP badge */}
      <span className="absolute top-5 end-5 z-10 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-ink text-white text-[11px] font-bold tracking-wide shadow-md">
        <Cpu className="w-3.5 h-3.5" /> MFP
      </span>

      {/* X-ray style image */}
      <div className="relative aspect-[4/3] bg-gradient-to-br from-primary/25 via-secondary to-primary/10 overflow-hidden">
        <Image
          src={s.image}
          alt={s.name}
          fittingType="fit"
          className="w-full h-full object-contain p-8 transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute bottom-0 inset-x-0 h-px ink-gradient opacity-60" />
      </div>

      <div className="flex flex-col flex-1 p-6">
        <h3 className="font-heading text-xl font-extrabold">{s.name}</h3>
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.description}</p>

        <div className="mt-4 inline-flex items-baseline gap-2 self-start">
          <span className="font-heading text-3xl font-extrabold text-accent">{s.speed}</span>
          <span className="text-sm font-semibold text-muted-foreground">صفحة/دقيقة</span>
        </div>

        <ul className="mt-4 space-y-2.5">
          {s.features?.map((f) => (
            <li key={f} className="flex items-start gap-2.5 text-sm">
              <span className="grid place-items-center w-5 h-5 rounded-full bg-primary/50 text-accent shrink-0 mt-0.5">
                <Check className="w-3 h-3" />
              </span>
              <span className="text-foreground/80">{f}</span>
            </li>
          ))}
        </ul>

        <button
          onClick={() => requestQuote({ name: s.name, model: s.model || "", category: "machine" })}
          className="mt-6 inline-flex items-center justify-center gap-2 w-full py-3 rounded-2xl bg-ink text-white font-bold text-sm hover:opacity-90 transition"
        >
          <MessageCircle className="w-4 h-4" /> اطلب عرض سعر
        </button>
      </div>
    </article>
  );
}
