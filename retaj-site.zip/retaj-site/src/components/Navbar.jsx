import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Phone, Menu, X, Search, Moon, Sun, Printer } from "lucide-react";
import { SITE, NAV_LINKS } from "@/lib/site";
import { useTheme } from "@/lib/theme";

export default function Navbar({ onOpenSearch }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { theme, toggle } = useTheme();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [location.pathname]);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "glass border-b border-border/60 shadow-sm" : "bg-transparent"
      }`}
    >
      <nav className="mx-auto max-w-[1400px] px-5 lg:px-10 h-20 flex items-center justify-between gap-4 py-3">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5 shrink-0 group">
          <span className="grid place-items-center w-10 h-10 rounded-xl ink-gradient text-white shadow-md group-hover:scale-105 transition-transform">
            <Printer className="w-5 h-5" />
          </span>
          <span className="leading-tight">
            <span className="block font-heading font-extrabold text-lg tracking-tight">
              {SITE.brand}
            </span>
            <span className="block text-[10px] text-muted-foreground font-medium">
              {SITE.tagline}
            </span>
          </span>
        </Link>

        {/* Desktop nav */}
        <ul className="hidden lg:flex items-center gap-1">
          {NAV_LINKS.map((l) => {
            const active = location.pathname === l.to;
            return (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className={`relative px-4 py-2 rounded-full text-sm font-semibold transition-colors ${
                    active
                      ? "text-accent-foreground bg-accent"
                      : "text-foreground/80 hover:text-foreground hover:bg-secondary"
                  }`}
                >
                  {l.label}
                </Link>
              </li>
            );
          })}
        </ul>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSearch}
            aria-label="بحث"
            className="grid place-items-center w-10 h-10 rounded-full hover:bg-secondary transition-colors"
          >
            <Search className="w-5 h-5" />
          </button>
          <button
            onClick={toggle}
            aria-label="الوضع الليلي"
            className="grid place-items-center w-10 h-10 rounded-full hover:bg-secondary transition-colors"
          >
            {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          <a
            href={`tel:${SITE.phoneTel}`}
            className="hidden sm:inline-flex items-center gap-2 ps-3 pe-4 py-2.5 rounded-full bg-accent text-accent-foreground text-sm font-bold shadow-md hover:brightness-105 transition"
          >
            <Phone className="w-4 h-4" />
            {SITE.phone}
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="القائمة"
            className="lg:hidden grid place-items-center w-10 h-10 rounded-full hover:bg-secondary transition-colors"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-500 ${
          open ? "max-h-96 glass border-b border-border/60" : "max-h-0"
        }`}
      >
        <ul className="px-5 py-4 flex flex-col gap-1">
          {NAV_LINKS.map((l) => {
            const active = location.pathname === l.to;
            return (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className={`block px-4 py-3 rounded-xl text-base font-semibold transition-colors ${
                    active ? "text-accent-foreground bg-accent" : "hover:bg-secondary"
                  }`}
                >
                  {l.label}
                </Link>
              </li>
            );
          })}
          <li>
            <a
              href={`tel:${SITE.phoneTel}`}
              className="flex items-center gap-2 px-4 py-3 rounded-xl bg-accent text-accent-foreground font-bold"
            >
              <Phone className="w-4 h-4" /> {SITE.phone}
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
