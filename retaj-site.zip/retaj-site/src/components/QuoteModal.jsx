import React, { createContext, useContext, useState, useEffect } from "react";
import { sendInquiry } from "@/lib/inquiry";
import { X, Send, Loader2, CheckCircle2 } from "lucide-react";

const QuoteContext = createContext(null);

export function useQuote() {
  return useContext(QuoteContext) || { requestQuote: () => {} };
}

export function QuoteProvider({ children }) {
  const [open, setOpen] = useState(false);
  const [product, setProduct] = useState({ name: "", model: "", category: "machine" });
  const [form, setForm] = useState({ name: "", phone: "", company: "", notes: "", website: "" });
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const requestQuote = (p = {}) => {
    setProduct({
      name: p.name || "",
      model: p.model || "",
      category: p.category || "machine",
    });
    setForm({ name: "", phone: "", company: "", notes: p.notes || "", website: "" });
    setDone(false);
    setError("");
    setOpen(true);
  };

  const close = () => setOpen(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      setError("من فضلك أكمل الاسم ورقم الموبايل.");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      await sendInquiry({
        name: form.name.trim(),
        phone: form.phone.trim(),
        company: form.company.trim(),
        notes: form.notes.trim(),
        model: product.model ? `${product.name} — ${product.model}` : product.name,
        request_type: "عرض سعر",
        category: product.category,
        website: form.website,
      });
      setDone(true);
    } catch {
      setError("حدث خطأ أثناء الإرسال. حاول مرة أخرى أو تواصل معنا على الواتساب.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <QuoteContext.Provider value={{ requestQuote }}>
      {children}
      {open && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-ink/70 backdrop-blur-sm" onClick={close} />
          <div className="relative w-full max-w-md bg-card rounded-3xl border border-border shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="relative px-6 py-5 border-b border-border/60">
              <h3 className="font-heading text-lg font-extrabold pe-8">
                عرض سعر — {product.name}
              </h3>
              <button
                onClick={close}
                aria-label="إغلاق"
                className="absolute top-4 end-4 grid place-items-center w-8 h-8 rounded-full hover:bg-secondary transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {done ? (
              <div className="p-8 text-center">
                <CheckCircle2 className="w-14 h-14 text-accent mx-auto mb-4" />
                <h4 className="font-heading text-xl font-extrabold">تم استلام طلبك</h4>
                <p className="mt-2 text-sm text-muted-foreground">
                  سيتم التواصل معك في أقرب وقت لتأكيد عرض السعر.
                </p>
                <button
                  onClick={close}
                  className="mt-6 px-5 py-2.5 rounded-2xl bg-secondary font-bold text-sm hover:bg-primary/30 transition"
                >
                  إغلاق
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="p-6">
                {/* honeypot (hidden from real users) */}
                <input
                  type="text"
                  name="website"
                  value={form.website}
                  onChange={(e) => set("website", e.target.value)}
                  tabIndex={-1}
                  autoComplete="off"
                  aria-hidden="true"
                  style={{ position: "absolute", left: "-9999px", opacity: 0, height: 0, width: 0 }}
                />
                <Field label="الاسم *">
                  <input
                    className="qinput"
                    value={form.name}
                    onChange={(e) => set("name", e.target.value)}
                    placeholder="اسمك الكامل"
                  />
                </Field>
                <Field label="رقم الموبايل *">
                  <input
                    className="qinput"
                    value={form.phone}
                    onChange={(e) => set("phone", e.target.value)}
                    placeholder="01xxxxxxxxx"
                    dir="ltr"
                  />
                </Field>
                <Field label="اسم الشركة (اختياري)">
                  <input
                    className="qinput"
                    value={form.company}
                    onChange={(e) => set("company", e.target.value)}
                    placeholder="اسم الشركة"
                  />
                </Field>
                <Field label="ملاحظات">
                  <textarea
                    className="qinput min-h-[88px] resize-y"
                    value={form.notes}
                    onChange={(e) => set("notes", e.target.value)}
                    placeholder="أي تفاصيل إضافية"
                  />
                </Field>

                {error && <p className="mt-3 text-sm text-destructive font-semibold">{error}</p>}

                <button
                  type="submit"
                  disabled={submitting}
                  className="mt-5 inline-flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl bg-accent text-accent-foreground font-bold hover:brightness-105 transition disabled:opacity-60"
                >
                  {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-4 h-4" />}
                  إرسال الطلب
                </button>
              </form>
            )}
          </div>

          <style>{`
            .qinput {
              width: 100%;
              padding: 0.7rem 1rem;
              border-radius: 0.85rem;
              border: 1px solid hsl(var(--border));
              background: hsl(var(--background));
              color: hsl(var(--foreground));
              font-size: 0.95rem;
              outline: none;
              transition: border-color .2s, box-shadow .2s;
            }
            .qinput:focus { border-color: hsl(var(--accent)); box-shadow: 0 0 0 3px hsl(var(--accent) / .15); }
          `}</style>
        </div>
      )}
    </QuoteContext.Provider>
  );
}

function Field({ label, children }) {
  return (
    <label className="block mb-3">
      <span className="block text-sm font-semibold mb-1.5">{label}</span>
      {children}
    </label>
  );
}
