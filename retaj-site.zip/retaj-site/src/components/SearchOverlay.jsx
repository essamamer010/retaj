import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X, Cpu, Droplet, Printer } from "lucide-react";

export default function SearchOverlay({ open, onClose, machines = [], toners = [] }) {
  const [q, setQ] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (open) {
      setQ("");
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return { machines: [], toners: [] };
    const m = machines.filter(
      (x) =>
        x.name?.toLowerCase().includes(term) ||
        x.model?.toLowerCase().includes(term) ||
        x.description?.toLowerCase().includes(term)
    );
    const t = toners.filter(
      (x) =>
        x.name?.toLowerCase().includes(term) ||
        x.models?.toLowerCase().includes(term)
    );
    return { machines: m, toners: t };
  }, [q, machines, toners]);

  if (!open) return null;

  const go = (path) => {
    onClose();
    navigate(path);
  };

  return (
    <div className="fixed inset-0 z-[60] flex flex-col">
      <div className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative mx-auto mt-0 w-full max-w-3xl px-5 pt-24">
        <div className="glass rounded-3xl border border-border/60 shadow-2xl overflow-hidden">
          <div className="flex items-center gap-3 px-5 py-4 border-b border-border/60">
            <Search className="w-5 h-5 text-accent" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث: موديل توشيبا، نظام MFP، أو حبارة…"
              className="flex-1 bg-transparent outline-none text-lg font-medium placeholder:text-muted-foreground/60"
            />
            <button onClick={onClose} className="grid place-items-center w-9 h-9 rounded-full hover:bg-secondary">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto p-4">
            {!q.trim() && (
              <div className="py-10 text-center text-muted-foreground text-sm">
                اكتب للبحث في الماكينات، أنظمة MFP، والأحبار.
              </div>
            )}

            {q.trim() && results.machines.length === 0 && results.toners.length === 0 && (
              <div className="py-10 text-center text-muted-foreground text-sm">
                لا توجد نتائج لـ «{q}».
              </div>
            )}

            {results.machines.length > 0 && (
              <div className="mb-3">
                <p className="flex items-center gap-2 px-2 text-xs font-bold text-muted-foreground mb-2">
                  <Printer className="w-4 h-4 text-accent" /> ماكينات وأنظمة MFP
                </p>
                <ul className="space-y-1">
                  {results.machines.map((m) => (
                    <li key={m.id}>
                      <button
                        onClick={() => go("/machines")}
                        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary text-start transition"
                      >
                        {m.category === "mfp" ? (
                          <Cpu className="w-4 h-4 text-accent shrink-0" />
                        ) : (
                          <Printer className="w-4 h-4 text-accent shrink-0" />
                        )}
                        <span className="flex-1">
                          <span className="block font-semibold text-sm">{m.name}</span>
                          <span className="block text-xs text-muted-foreground" dir="ltr">{m.model}</span>
                        </span>
                        {m.category === "mfp" && (
                          <span className="text-[10px] font-bold bg-ink text-white px-2 py-0.5 rounded-full">MFP</span>
                        )}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {results.toners.length > 0 && (
              <div>
                <p className="flex items-center gap-2 px-2 text-xs font-bold text-muted-foreground mb-2">
                  <Droplet className="w-4 h-4 text-accent" /> أحبار
                </p>
                <ul className="space-y-1">
                  {results.toners.map((t) => (
                    <li key={t.id}>
                      <button
                        onClick={() => go("/toners")}
                        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary text-start transition"
                      >
                        <Droplet className="w-4 h-4 text-accent shrink-0" />
                        <span className="flex-1">
                          <span className="block font-semibold text-sm">{t.name}</span>
                          <span className="block text-xs text-muted-foreground" dir="ltr">{t.models}</span>
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
