import React, { useState } from "react";
import { MessageCircle, Droplet } from "lucide-react";
import { useQuote } from "@/components/QuoteModal";

const OPTIONS = ["تعبئة", "هاي كوبي", "أصلي"];

export default function TonerCard({ toner }) {
  const [selected, setSelected] = useState("أصلي");
  const t = toner;
  const isSet = t.type === "set";
  const { requestQuote } = useQuote();

  return (
    <article className="lift group flex flex-col bg-card rounded-3xl border border-border/70 overflow-hidden shadow-sm">
      <div className="p-5 pb-0">
        <div className="flex items-center gap-2 mb-3">
          {isSet ? (
            <div className="flex items-center gap-1.5">
              {["#0F172A", "#0EA5E9", "#EAB308", "#EF4444"].map((c) => (
                <span key={c} className="w-4 h-4 rounded-full border border-border/60" style={{ background: c }} />
              ))}
            </div>
          ) : (
            <span className="w-4 h-4 rounded-full bg-ink border border-border/60" />
          )}
          <span className="text-xs font-bold text-muted-foreground">
            {isSet ? "طقم ٤ حبارات" : "حبارة أسود"}
          </span>
        </div>

        <h3 className="font-heading text-lg font-extrabold">{t.name}</h3>
        <p className="mt-1 text-sm text-muted-foreground" dir="ltr">{t.models}</p>
        {t.ink_type && (
          <p className="mt-1 text-xs text-foreground/60 inline-flex items-center gap-1">
            <Droplet className="w-3.5 h-3.5 text-accent" /> {t.ink_type}
          </p>
        )}
      </div>

      <div className="p-5 flex flex-col flex-1">
        <div className="flex p-1 rounded-2xl bg-secondary">
          {OPTIONS.map((o) => (
            <button
              key={o}
              onClick={() => setSelected(o)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition ${
                selected === o ? "bg-card shadow-sm text-accent" : "text-muted-foreground"
              }`}
            >
              {o}
            </button>
          ))}
        </div>

        <p className="mt-3 text-xs text-muted-foreground text-center">{t.tagline || "أقصى عمر وجودة"}</p>

        <button
          onClick={() => requestQuote({ name: t.name, model: `${t.models} — النوع: ${selected}`, category: "toner" })}
          className="mt-4 inline-flex items-center justify-center gap-2 w-full py-3 rounded-2xl bg-accent text-accent-foreground font-bold text-sm hover:brightness-105 transition"
        >
          <MessageCircle className="w-4 h-4" /> اطلب هذا الموديل
        </button>
      </div>
    </article>
  );
}
