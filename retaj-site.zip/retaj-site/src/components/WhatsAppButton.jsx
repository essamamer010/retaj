import React from "react";
import { Phone, MessageCircle } from "lucide-react";
import { SITE, waLink } from "@/lib/site";

export default function WhatsAppButton() {
  return (
    <>
      {/* Floating side rail — desktop */}
      <div className="hidden sm:flex fixed bottom-6 left-4 z-40 flex-col items-center gap-3">
        <a
          href={`tel:${SITE.phoneTel}`}
          aria-label="اتصل بنا"
          className="grid place-items-center w-12 h-12 rounded-full bg-[#FF5959] text-white shadow-lg shadow-red-500/30 hover:scale-110 transition-transform"
        >
          <Phone className="w-5 h-5" />
        </a>
        <span
          className="text-[10px] font-bold tracking-[0.2em] text-muted-foreground"
          style={{ writingMode: "vertical-rl" }}
          dir="ltr"
        >
          {SITE.phone}
        </span>
        <a
          href={waLink()}
          target="_blank"
          rel="noreferrer"
          aria-label="واتساب"
          className="grid place-items-center w-12 h-12 rounded-full bg-[#25D366] text-white shadow-lg shadow-green-500/30 animate-pulse-ring hover:scale-110 transition-transform"
        >
          <MessageCircle className="w-5 h-5" />
        </a>
      </div>

      {/* Mobile bottom bar */}
      <div className="sm:hidden fixed bottom-4 inset-x-4 z-40 flex gap-3">
        <a
          href={`tel:${SITE.phoneTel}`}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#FF5959] text-white font-bold text-sm shadow-lg"
        >
          <Phone className="w-4 h-4" /> اتصل الآن
        </a>
        <a
          href={waLink()}
          target="_blank"
          rel="noreferrer"
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#25D366] text-white font-bold text-sm shadow-lg"
        >
          <MessageCircle className="w-4 h-4" /> واتساب
        </a>
      </div>
    </>
  );
}
