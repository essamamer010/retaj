import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ChevronRight, ChevronLeft } from "lucide-react";
import MachineCard from "@/components/MachineCard";
import SectionHeading from "@/components/SectionHeading";

export default function FeaturedMachines({ machines = [] }) {
  const trackRef = useRef(null);
  const [active, setActive] = useState(0);
  const count = machines.length;

  useEffect(() => {
    const track = trackRef.current;
    if (!track || count === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(Number(e.target.dataset.index));
        });
      },
      { root: track, threshold: 0.6 }
    );
    Array.from(track.children).forEach((c) => observer.observe(c));
    return () => observer.disconnect();
  }, [count]);

  const go = (i) => {
    const track = trackRef.current;
    if (!track) return;
    const clamped = Math.max(0, Math.min(i, count - 1));
    const card = track.children[clamped];
    if (card) card.scrollIntoView({ behavior: "smooth", inline: "start", block: "nearest" });
  };

  return (
    <section className="py-16 lg:py-24 bg-surface">
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
          <SectionHeading
            align="start"
            eyebrow="الماكينات"
            title="أحدث موديلات الماكينات التوشيبا، لكل مكتب حجمه"
            subtitle="ماكينات مختارة بعناية تغطي كل أحجام المكاتب — من المكتب الصغير للمطابع الداخلية الكبيرة."
          />
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => go(active - 1)}
              aria-label="السابق"
              className="grid place-items-center w-11 h-11 rounded-full bg-card border border-border hover:bg-secondary transition disabled:opacity-40 disabled:pointer-events-none"
              disabled={active <= 0}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={() => go(active + 1)}
              aria-label="التالي"
              className="grid place-items-center w-11 h-11 rounded-full bg-card border border-border hover:bg-secondary transition disabled:opacity-40 disabled:pointer-events-none"
              disabled={active >= count - 1}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <Link
              to="/machines"
              className="inline-flex items-center gap-2 ps-4 pe-5 py-3 rounded-2xl bg-card border border-border font-bold text-sm hover:bg-secondary transition"
            >
              كل الماكينات <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Controllable slider */}
        <div
          ref={trackRef}
          className="flex gap-5 overflow-x-auto snap-x snap-mandatory pb-2 -mx-5 px-5 lg:mx-0 lg:px-0 [&::-webkit-scrollbar]:hidden [scrollbar-width:none]"
        >
          {machines.map((m, i) => (
            <div
              key={m.id}
              data-index={i}
              className="snap-start shrink-0 w-[80%] sm:w-[46%] lg:w-[31%] xl:w-[23.5%]"
            >
              <MachineCard machine={m} />
            </div>
          ))}
        </div>

        {/* Dots */}
        {count > 1 && (
          <div className="flex items-center justify-center gap-2 mt-7">
            {machines.map((_, i) => (
              <button
                key={i}
                onClick={() => go(i)}
                aria-label={`الشريحة ${i + 1}`}
                className={`h-2 rounded-full transition-all ${
                  active === i ? "w-7 bg-accent" : "w-2 bg-border hover:bg-primary/40"
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
