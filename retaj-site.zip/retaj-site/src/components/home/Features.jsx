import React from "react";
import { ShieldCheck, CalendarClock, Wrench, FileCheck, Timer, Droplet, Truck } from "lucide-react";

const FEATURES = [
  { icon: Droplet, title: "جميع موديلات ماكينات التصوير توشيبا", desc: "كل موديلات توشيبا متوفرة — ألوان وأبيض وأسود، بكل السعات والإنتاجيات." },
  { icon: ShieldCheck, title: "ضمان لمدة سنة", desc: "ضمان شامل الصيانة وقطع الغيار طوال السنة الأولى بدون أي تكلفة إضافية." },
  { icon: CalendarClock, title: "زيارات دورية شهرية", desc: "فني متخصص يزورك كل شهر طوال فترة الضمان للفحص والتنظيف والضبط." },
  { icon: FileCheck, title: "عقود صيانة سنوية", desc: "بعد الضمان، عقود صيانة سنوية مرنة تحافظ على أداء ماكينتك." },
  { icon: Timer, title: "تلبية الأعطال خلال ٢٤ ساعة", desc: "من لحظة الإبلاغ، فريقنا عندك في أقل من ٢٤ ساعة." },
  { icon: Droplet, title: "حبر أصلي لا يقل عن ٥٠٪", desc: "تستلم الماكينة بنسبة حبر أصلي لا تقل عن ٥٠٪ لتبدأ الشغل فورًا." },
  { icon: Truck, title: "توريد وتركيب مجاني", desc: "التوصيل والتركيب مجانًا داخل القاهرة." },
  { icon: Wrench, title: "فريق صيانة محترف", desc: "فنيون متخصصون في جميع موديلات توشيبا على أعلى مستوى من الدقة." },
];

export default function Features() {
  return (
    <section className="py-16 lg:py-24">
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/40 text-accent text-xs font-bold mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" /> ليه ريتاج؟
          </span>
          <h2 className="font-heading text-3xl md:text-4xl font-extrabold text-balance">
            مميزات بنقدمها لكل عميل
          </h2>
          <p className="mt-3 text-muted-foreground text-lg leading-relaxed">
            شركة الريتاج للتجارة والتوريدات تأسست عام ١٩٩٩ في جمهورية مصر العربية، مقرها الرئيسي في
            القاهرة. الريتاج واحدة من الشركات الرائدة في الشرق الأوسط في استيراد وتوريد آلات ولوازم
            التصوير وقطع الغيار المستوردة والأحبار الأصلية، وجميع الخدمات التي تقدمها الشركة تتم
            بدقة وكفاءة عالية من الجودة والتميز.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-5">
          {FEATURES.map((f, i) => (
            <div
              key={f.title}
              className="lift group relative bg-card rounded-2xl border border-border/60 p-5 overflow-hidden"
            >
              <span className="absolute top-3 end-4 font-heading text-5xl font-extrabold text-primary/30 group-hover:text-accent/20 transition-colors">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="relative grid place-items-center w-12 h-12 rounded-2xl ink-gradient text-white mb-4 shadow-md">
                <f.icon className="w-5 h-5" />
              </span>
              <h3 className="relative font-heading font-bold text-base leading-snug">{f.title}</h3>
              <p className="relative mt-2 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
