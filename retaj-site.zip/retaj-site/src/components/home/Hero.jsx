import React from "react";
import { Link } from "react-router-dom";
import { Check, Phone, ArrowLeft, Clock, ShieldCheck } from "lucide-react";
import { Image } from "@/components/ui/image";
import { SITE } from "@/lib/site";

const POINTS = [
  "جميع موديلات ماكينات التصوير توشيبا",
  "زيارات دورية بشكل شهري طول فترة الضمان",
  "فريق صيانة محترف لتلبية الأعطال",
  "كل دا واكتر تحت سقف الريتاج",
];

export default function Hero({ heroImage }) {
  return (
    <section className="relative pt-28 lg:pt-36 pb-16 lg:pb-24 overflow-hidden">
      <div className="absolute inset-0 blueprint-grid opacity-50 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
      <div className="absolute -top-24 -start-24 w-96 h-96 rounded-full bg-primary/40 blur-3xl" />
      <div className="absolute -bottom-32 -end-20 w-[28rem] h-[28rem] rounded-full bg-accent/15 blur-3xl" />

      <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10 grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
        {/* Text */}
        <div className="order-2 lg:order-1">
          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/50 text-accent text-xs font-bold mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
            {SITE.tagline}
          </span>
          <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-extrabold leading-[1.1] tracking-tight text-balance">
            ماكينات تصوير{" "}
            <span className="relative inline-block">
              <span className="text-accent">توشيبا</span>
              <span className="absolute -bottom-1 inset-x-0 h-1.5 rounded-full bg-accent" />
            </span>
          </h1>

          <ul className="mt-7 space-y-3">
            {POINTS.map((p) => (
              <li key={p} className="flex items-center gap-3">
                <span className="grid place-items-center w-6 h-6 rounded-full bg-accent text-accent-foreground shrink-0">
                  <Check className="w-3.5 h-3.5" />
                </span>
                <span className="text-base md:text-lg text-foreground/85 font-medium">{p}</span>
              </li>
            ))}
          </ul>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Link
              to="/machines"
              className="inline-flex items-center gap-2 ps-5 pe-6 py-3.5 rounded-2xl bg-accent text-accent-foreground font-bold shadow-lg shadow-accent/25 hover:brightness-105 transition"
            >
              تصفح الماكينات <ArrowLeft className="w-4 h-4" />
            </Link>
            <a
              href={`tel:${SITE.phoneTel}`}
              className="inline-flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-card border border-border font-bold hover:bg-secondary transition"
            >
              <Phone className="w-4 h-4 text-accent" /> {SITE.phone}
            </a>
          </div>
        </div>

        {/* Image card */}
        <div className="order-1 lg:order-2 relative">
          <div className="relative rounded-[2rem] overflow-hidden border border-border/70 shadow-2xl bg-gradient-to-br from-primary/30 to-secondary">
            <Image
              src={heroImage}
              alt="ماكينة تصوير توشيبا"
              fittingType="fill"
              className="w-full aspect-[4/3] object-cover"
            />
            <div className="absolute bottom-4 end-4 flex items-center gap-3 bg-ink/85 backdrop-blur text-white rounded-2xl px-4 py-3 shadow-xl">
              <Clock className="w-6 h-6 text-accent" />
              <div className="leading-tight">
                <div className="text-xl font-extrabold">٢٤ ساعة</div>
                <div className="text-[11px] text-white/70">أقصى وقت للاستجابة</div>
              </div>
            </div>
            <div className="absolute top-4 start-4 inline-flex items-center gap-1.5 bg-card/90 backdrop-blur rounded-full px-3 py-1.5 text-xs font-bold shadow">
              <ShieldCheck className="w-4 h-4 text-accent" /> ضمان سنة شامل
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
