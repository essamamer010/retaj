import React from "react";
import { Cpu } from "lucide-react";
import MfpCard from "@/components/MfpCard";
import SectionHeading from "@/components/SectionHeading";

export default function MfpSystems({ systems = [] }) {
  return (
    <section className="py-16 lg:py-24">
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
        <SectionHeading
          eyebrow={
            <span className="inline-flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" /> Multi Function Printer
            </span>
          }
          title="أنظمة MFP متعددة الوظائف"
        />

        <div className="mt-12 grid md:grid-cols-3 gap-5 lg:gap-6">
          {systems.map((s) => (
            <MfpCard key={s.id} system={s} />
          ))}
        </div>
      </div>
    </section>
  );
}
