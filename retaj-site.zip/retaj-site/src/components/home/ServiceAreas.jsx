import React from "react";
import { SITE } from "@/lib/site";
import SectionHeading from "@/components/SectionHeading";

export default function ServiceAreas() {
  return (
    <section className="py-16 lg:py-24 bg-surface">
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10 text-center">
        <SectionHeading
          eyebrow="تغطية جغرافية"
          title="خدمتنا على مستوى الجمهورية"
          subtitle="من القاهرة لأقصى المحافظات — الريتاج بتوصل ماكيناتك وأحبارك وخدمات الصيانة لكل عملائها في جميع أنحاء جمهورية مصر العربية."
        />
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          {SITE.areas.map((a) => (
            <span
              key={a}
              className="px-5 py-2.5 rounded-full bg-card border border-border font-bold text-sm shadow-sm"
            >
              {a}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
