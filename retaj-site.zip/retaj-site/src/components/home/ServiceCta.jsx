import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, MapPin, Phone, Mail, MessageCircle, Calendar, Wrench, ShieldCheck, Package } from "lucide-react";
import { Image } from "@/components/ui/image";
import { SITE, waLink } from "@/lib/site";
import SectionHeading from "@/components/SectionHeading";

const TONER_TIERS = [
  { name: "تعبئة", desc: "الأوفر سعرًا" },
  { name: "هاي كوبي", desc: "كفاءة اقتصادية" },
  { name: "أصلي", desc: "أقصى عمر وجودة" },
];

const MAINTENANCE_STEPS = [
  { when: "اليوم الأول", title: "توريد وتركيب مجاني", icon: ShieldCheck },
  { when: "كل ٣٠ يومًا", title: "زيارة صيانة دورية", icon: Calendar },
  { when: "في أي وقت", title: "استجابة خلال ٢٤ ساعة", icon: Wrench },
  { when: "متوفر دائمًا", title: "جميع قطع الغيار الأصلية", icon: Package },
];

export default function ServiceCta({ maintenanceImage }) {
  return (
    <>
      {/* Maintenance teaser */}
      <section className="py-16 lg:py-24 bg-surface">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          <div className="relative order-2 lg:order-1">
            <div className="rounded-[2rem] overflow-hidden border border-border/70 shadow-xl bg-gradient-to-br from-primary/25 to-secondary">
              <Image
                src={maintenanceImage}
                alt="صيانة ماكينات توشيبا"
                fittingType="fill"
                className="w-full aspect-[4/3] object-cover"
              />
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <SectionHeading
              align="start"
              eyebrow="الصيانة وقطع الغيار"
              title="رحلة سنة كاملة من الاطمئنان"
              subtitle="ضمان شامل، زيارات دورية، جميع قطع الغيار الأصلية، وعقود صيانة سنوية لكل موديلات توشيبا."
            />
            <ul className="mt-8 space-y-4">
              {MAINTENANCE_STEPS.map((s) => (
                <li key={s.title} className="flex items-start gap-4">
                  <span className="grid place-items-center w-12 h-12 rounded-2xl ink-gradient text-white shrink-0 shadow-md">
                    <s.icon className="w-5 h-5" />
                  </span>
                  <div>
                    <div className="text-xs font-bold text-accent">{s.when}</div>
                    <div className="font-heading font-bold text-lg">{s.title}</div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/30 text-accent text-sm font-bold">
              <Package className="w-4 h-4" /> لدينا جميع قطع الغيار الأصلية
            </div>
            <Link
              to="/maintenance"
              className="mt-4 inline-flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-ink text-white font-bold hover:opacity-90 transition"
            >
              الصيانة وقطع الغيار <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Toners teaser */}
      <section className="py-16 lg:py-24">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <SectionHeading
            eyebrow="الأحبار"
            title="الحبر المناسب لكل ماكينة"
            subtitle="حبارات فردية وأطقم ألوان كاملة (أسود - أزرق - أصفر - أحمر) لأغلب موديلات توشيبا."
          />
          <div className="mt-10 grid sm:grid-cols-3 gap-5">
            {TONER_TIERS.map((t) => (
              <div key={t.name} className="lift bg-card rounded-3xl border border-border/60 p-6 text-center">
                <div className="font-heading text-2xl font-extrabold text-accent">{t.name}</div>
                <div className="mt-1 text-sm text-muted-foreground">{t.desc}</div>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              to="/toners"
              className="inline-flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-accent text-accent-foreground font-bold hover:brightness-105 transition"
            >
              اطلب حبارتك <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 lg:py-24">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="relative overflow-hidden rounded-[2.5rem] ink-gradient p-10 lg:p-16 text-center">
            <div className="absolute inset-0 blueprint-grid opacity-20" />
            <div className="relative">
              <h2 className="font-heading text-3xl md:text-5xl font-extrabold text-ink text-balance">
                مكالمة واحدة وماكينتك تشتغل
              </h2>
              <p className="mt-4 text-ink/70 text-lg max-w-xl mx-auto">
                فريقنا جاهز يرد على استفساراتك ويوصلك عرض السعر المناسب لمكتبك.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <a
                  href={`tel:${SITE.phoneTel}`}
                  className="inline-flex items-center gap-2 px-6 py-4 rounded-2xl bg-ink text-white font-bold shadow-lg hover:opacity-90 transition"
                >
                  <Phone className="w-5 h-5" /> {SITE.phone}
                </a>
                <a
                  href={waLink()}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-4 rounded-2xl bg-[#25D366] text-white font-bold shadow-lg hover:brightness-105 transition"
                >
                  <MessageCircle className="w-5 h-5" /> واتساب
                </a>
                <a
                  href={`mailto:${SITE.email}`}
                  className="inline-flex items-center gap-2 px-6 py-4 rounded-2xl bg-card text-ink font-bold border border-border hover:bg-secondary transition"
                >
                  <Mail className="w-5 h-5" /> {SITE.email}
                </a>
              </div>
              <p className="mt-6 inline-flex items-center gap-2 text-sm text-ink/70">
                <MapPin className="w-4 h-4" />
                <a href={SITE.mapsUrl} target="_blank" rel="noreferrer">
                  {SITE.address}
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
