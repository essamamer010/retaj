import React from "react";

// Replaces the Base44 <Image> helper with a plain lazy-loaded <img>.
export function Image({ src, alt = "", className = "", fittingType, ...rest }) {
  return <img src={src} alt={alt} className={className} loading="lazy" decoding="async" {...rest} />;
}
