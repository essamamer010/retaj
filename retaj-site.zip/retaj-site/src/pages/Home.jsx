import React from "react";
import Hero from "@/components/home/Hero";
import ServiceAreas from "@/components/home/ServiceAreas";
import Features from "@/components/home/Features";
import FeaturedMachines from "@/components/home/FeaturedMachines";
import MfpSystems from "@/components/home/MfpSystems";
import ServiceCta from "@/components/home/ServiceCta";
import images from "@/data/images.json";
import { getMachines } from "@/lib/data";

const machines = getMachines({ featured: true, limit: 5 });
const systems = getMachines({ category: "mfp", limit: 3 });

export default function Home() {
  return (
    <>
      <Hero heroImage={images.hero} />
      <ServiceAreas />
      <Features />
      <FeaturedMachines machines={machines} />
      <MfpSystems systems={systems} />
      <ServiceCta maintenanceImage={images.maintenance} />
    </>
  );
}
