import React, { useMemo, useState } from "react";
import MachineCard from "@/components/MachineCard";
import { Filter } from "lucide-react";
import { getMachines } from "@/lib/data";

const TIERS = [
  { key: "", label: "الكل" },
  { key: "low", label: "حتى ١٠ آلاف نسخة" },
  { key: "medium", label: "١٠ – ٢٠ ألف نسخة" },
  { key: "high", label: "٢٠ – ٣٠ ألف نسخة" },
  { key: "tier40", label: "٤٠ ألف نسخة" },
  { key: "tier50", label: "٥٠ ألف نسخة" },
];

const TYPES = [
  { key: "", label: "الكل" },
  { key: "bw", label: "أبيض وأسود" },
  { key: "color", label: "ألوان" },
];

export default function Machines() {
  const [tier, setTier] = useState("");
  const [type, setType] = useState("");

  const machines = useMemo(
    () => getMachines({ category: "standard", capacity_tier: tier, type }),
    [tier, type]
  );

  return (
    <div>
      {/* Fixed filter bar — always visible under the navbar */}
      <section className="fixed top-20 inset-x-0 z-40 glass border-b border-border/60 shadow-sm py-3">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center gap-2 text-xs font-bold text-muted-foreground">
                <Filter className="w-3.5 h-3.5" /> قارن لمكتبك — كام نسخة بتطبع في الشهر؟
              </div>
              <div className="flex flex-wrap gap-1.5">
                {TIERS.map((t) => (
                  <button
                    key={t.key}
                    onClick={() => setTier(t.key)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition ${
                      tier === t.key ? "bg-accent text-accent-foreground" : "bg-secondary hover:bg-primary/30"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="text-xs font-bold text-muted-foreground">نوع الطباعة</div>
              <div className="flex flex-wrap gap-1.5">
                {TYPES.map((t) => (
                  <button
                    key={t.key}
                    onClick={() => setType(t.key)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition ${
                      type === t.key ? "bg-accent text-accent-foreground" : "bg-secondary hover:bg-primary/30"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="pt-[230px] lg:pt-[220px]">
        {/* Hero */}
        <section className="relative overflow-hidden pb-10">
          <div className="absolute inset-0 blueprint-grid opacity-40 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
          <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10 text-center">
            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/50 text-accent text-xs font-bold mb-4">
              ماكينات تصوير توشيبا
            </span>
            <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-balance">
              استثمار يشتغل لمكتبك
            </h1>
            <p className="mt-4 max-w-2xl mx-auto text-muted-foreground text-lg leading-relaxed">
              موديلات ماكينات التصوير توشيبا، بضمان سنة شامل الصيانة وقطع الغيار، وحبر أصلي لا يقل عن ٥٠٪ عند الاستلام.
            </p>
          </div>
        </section>

        {/* Grid */}
        <section className="py-10 lg:py-14">
          <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
            {machines.length === 0 ? (
              <div className="text-center py-24 text-muted-foreground">لا توجد ماكينات بهذه المواصفات.</div>
            ) : (
              <>
                <h2 className="font-heading text-2xl font-extrabold mb-6">ماكينات التصوير توشيبا</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {machines.map((m) => (
                    <MachineCard key={m.id} machine={m} />
                  ))}
                </div>
              </>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
