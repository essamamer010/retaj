import React from "react";
import { Wrench, Cog, FileCheck, ShieldCheck, Calendar, Timer, Truck } from "lucide-react";
import { Image } from "@/components/ui/image";
import InquiryForm from "@/components/InquiryForm";
import SectionHeading from "@/components/SectionHeading";
import images from "@/data/images.json";

const STEPS = [
  { when: "اليوم الأول", title: "توريد وتركيب مجاني", desc: "نوصل الماكينة ونركبها ونشغلها في مكتبك داخل القاهرة مجانًا.", icon: Truck },
  { when: "كل ٣٠ يومًا", title: "زيارة صيانة دورية", desc: "فحص وتنظيف وضبط شهري طول فترة الضمان عشان الماكينة ما تقفش.", icon: Calendar },
  { when: "في أي وقت", title: "استجابة خلال ٢٤ ساعة", desc: "بلّغ عن العطل وفريقنا عندك في أقل من ٢٤ ساعة.", icon: Timer },
  { when: "بعد السنة", title: "عقد صيانة سنوي", desc: "كمّل مع ريتاج بعقد صيانة سنوي يحافظ على نفس مستوى الخدمة.", icon: FileCheck },
];

const SERVICES = [
  { icon: Cog, title: "قطع غيار أصلية", desc: "كل قطع غيار توشيبا الأصلية متوفرة لدىنا لجميع الموديلات، عشان ماكينتك تشتغل بكفاءة عالية." },
  { icon: Wrench, title: "صيانة احترافية", desc: "فريق فني متخصص في صيانة جميع موديلات توشيبا على أعلى مستوى من الدقة والمهارة." },
  { icon: FileCheck, title: "عقود صيانة", desc: "عقود صيانة سنوية مرنة تحافظ على أداء ماكينتك وتطيل عمرها الافتراضي." },
  { icon: ShieldCheck, title: "ضمان شامل", desc: "ضمان سنة شامل الصيانة وقطع الغيار، مع زيارات دورية شهرية طوال فترة الضمان." },
];

export default function Maintenance() {
  return (
    <div className="pt-28 lg:pt-36">
      {/* Hero */}
      <section className="relative overflow-hidden pb-10">
        <div className="absolute inset-0 blueprint-grid opacity-40 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10 text-center">
          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/50 text-accent text-xs font-bold mb-4">
            الصيانة وقطع الغيار
          </span>
          <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-balance">
            رحلة سنة كاملة من الاطمئنان
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-muted-foreground text-lg leading-relaxed">
            ضمان شامل الصيانة وقطع الغيار، زيارات دورية شهرية، وعقود صيانة سنوية لكل موديلات توشيبا.
          </p>
        </div>
      </section>

      {/* Timeline + image */}
      <section className="py-10 lg:py-16">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          <div className="relative">
            <div className="rounded-[2rem] overflow-hidden border border-border/70 shadow-xl bg-gradient-to-br from-primary/25 to-secondary">
              <Image
                src={images.maintenance}
                alt="صيانة ماكينات توشيبا"
                fittingType="fill"
                className="w-full aspect-[4/3] object-cover"
              />
            </div>
          </div>
          <div>
            <SectionHeading align="start" eyebrow="خطوات الصيانة" title="كيف نحافظ على ماكينتك طول السنة" />
            <ol className="mt-8 space-y-5">
              {STEPS.map((s, i) => (
                <li key={s.title} className="flex items-start gap-4">
                  <div className="flex flex-col items-center">
                    <span className="grid place-items-center w-12 h-12 rounded-2xl ink-gradient text-white shrink-0 shadow-md">
                      <s.icon className="w-5 h-5" />
                    </span>
                    {i < STEPS.length - 1 && <span className="w-px h-8 bg-border mt-2" />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-accent">{s.when}</div>
                    <div className="font-heading font-bold text-lg">{s.title}</div>
                    <p className="text-sm text-muted-foreground leading-relaxed mt-1">{s.desc}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* Services grid */}
      <section className="py-12 lg:py-20 bg-surface">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <SectionHeading
            eyebrow="قطع الغيار والصيانة"
            title="كل ما تحتاجه ماكينتك تحت سقف واحد"
            subtitle="قطع غيار أصلية، صيانة احترافية، وعقود صيانة سنوية لجميع موديلات توشيبا."
          />
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {SERVICES.map((s) => (
              <div key={s.title} className="lift bg-card rounded-2xl border border-border/60 p-6">
                <span className="grid place-items-center w-12 h-12 rounded-2xl ink-gradient text-white mb-4 shadow-md">
                  <s.icon className="w-5 h-5" />
                </span>
                <h3 className="font-heading font-bold text-lg">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Form */}
      <section className="py-12 lg:py-20">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 grid lg:grid-cols-2 gap-10 lg:gap-16 items-start">
          <SectionHeading
            align="start"
            eyebrow="اطلب الآن"
            title="فورم طلب الصيانة"
            subtitle="اكتب موديل الماكينة ونوع الطلب (صيانة دورية، عقد صيانة، أو قطعة غيار) وسيتم التواصل معك في أقرب وقت."
          />
          <InquiryForm
            category="maintenance"
            requestLabel="نوع الطلب"
            requestOptions={["صيانة دورية", "عقد صيانة", "قطعة غيار"]}
          />
        </div>
      </section>
    </div>
  );
}
