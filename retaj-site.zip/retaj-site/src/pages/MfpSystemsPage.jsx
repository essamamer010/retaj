import React from "react";
import MfpCard from "@/components/MfpCard";
import { Cpu } from "lucide-react";
import { getMachines } from "@/lib/data";

const systems = getMachines({ category: "mfp", limit: 20 });

export default function MfpSystemsPage() {
  return (
    <div className="pt-28 lg:pt-36">
      {/* Hero */}
      <section className="relative overflow-hidden pb-10">
        <div className="absolute inset-0 blueprint-grid opacity-40 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10 text-center">
          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/50 text-accent text-xs font-bold mb-4">
            <Cpu className="w-3.5 h-3.5" /> Multi Function Printer
          </span>
          <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-balance">
            ماكينات MFP
          </h1>
        </div>
      </section>

      {/* Grid */}
      <section className="py-10 lg:py-14">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          {systems.length === 0 ? (
            <div className="text-center py-24 text-muted-foreground">لا توجد أنظمة متاحة حاليًا.</div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
              {systems.map((s) => (
                <MfpCard key={s.id} system={s} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
