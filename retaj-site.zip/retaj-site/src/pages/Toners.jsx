import React, { useMemo, useState } from "react";
import TonerCard from "@/components/TonerCard";
import InquiryForm from "@/components/InquiryForm";
import SectionHeading from "@/components/SectionHeading";
import { getToners } from "@/lib/data";

const FILTERS = [
  { key: "", label: "الكل" },
  { key: "individual", label: "حبارات فردية" },
  { key: "set", label: "أطقم ألوان" },
];

export default function Toners() {
  const [filter, setFilter] = useState("");
  const toners = useMemo(() => getToners({ type: filter }), [filter]);

  return (
    <div className="pt-28 lg:pt-36">
      <section className="relative overflow-hidden pb-8">
        <div className="absolute inset-0 blueprint-grid opacity-40 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10 text-center">
          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/50 text-accent text-xs font-bold mb-4">
            الأحبار
          </span>
          <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-balance">
            حبر لكل ماكينة توشيبا
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-muted-foreground text-lg leading-relaxed">
            كل موديل متاح بثلاث اختيارات: تعبئة، هاي كوبي، أو أصلي. اختار الموديل ونوع الحبر
            وإحنا نتواصل معاك.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-4">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 flex justify-center">
          <div className="flex p-1.5 rounded-2xl bg-secondary">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`px-5 py-2.5 rounded-xl text-sm font-bold transition ${
                  filter === f.key ? "bg-card shadow-sm text-accent" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Grid */}
      <section className="py-8 lg:py-12">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {toners.map((t) => (
              <TonerCard key={t.id} toner={t} />
            ))}
          </div>
        </div>
      </section>

      {/* Order form */}
      <section className="py-12 lg:py-20 bg-surface">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 grid lg:grid-cols-2 gap-10 lg:gap-16 items-start">
          <SectionHeading
            align="start"
            eyebrow="اطلب الآن"
            title="فورم طلب الأحبار"
            subtitle="اكتب موديل الحبارة المطلوبة واختار نوع الحبر (تعبئة / هاي كوبي / أصلي)، وسيتم التواصل معك في أقرب وقت."
          />
          <InquiryForm
            category="toner"
            requestLabel="نوع الحبر"
            requestOptions={["تعبئة", "هاي كوبي", "أصلي"]}
          />
        </div>
      </section>
    </div>
  );
}
